class CommuterList {
  final int id;
  final String name;
  final String place;
  final String type;

  CommuterList({
    this.id,
    this.place,
    this.name,
    this.type
  });
}
