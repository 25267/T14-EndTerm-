package com.example.lab12_zh

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
